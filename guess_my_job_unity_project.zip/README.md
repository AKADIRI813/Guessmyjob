Guess My Job - Unity Project Skeleton
=====================================

What this archive contains:
- Assets/Scripts/GameManager.cs  -> core C# skeleton (game logic placeholders)
- Assets/Resources/strings.json  -> UI strings & 20 yes/no questions in FR/EN/AR
- Assets/Resources/jobs.json     -> list of jobs (translations)
- LICENSE (MIT)
- README_BUILD.md -> instructions to upload repo to Codemagic or Unity Cloud Build and get APK/IPA

IMPORTANT:
- This is a skeleton project (scripts + data). It does NOT include Unity scene files or binary assets.
- To produce a playable APK/IPA you should open this project in Unity, create scenes, attach scripts, and then use a cloud build service (Codemagic or Unity Cloud Build) or build locally with Unity Editor + required build modules.
- For iOS builds you must configure code signing (Apple Developer account + provisioning profiles, certificate). Codemagic and Unity Cloud Build can manage code signing but you'll need to provide credentials/profiles as described in their docs.

Recommended cloud build options:
- Codemagic (supports Unity, can build iOS without owning a Mac): https://codemagic.io/start/ (see README_BUILD.md for steps). Codemagic docs: building Unity apps -> https://docs.codemagic.io/yaml-quick-start/building-a-unity-app/
- Unity Cloud Build / Unity Build Automation: https://docs.unity3d.com/Manual/UnityCloudBuild.html and https://docs.unity.com/ugs/manual/devops/manual/build-automation/overview

Quick steps to get an APK/IPA from this repo:
1) Put this folder under Git (GitHub/GitLab/Bitbucket).
2) Sign up to Codemagic or Unity Cloud Build.
3) Connect your repository and configure a Unity build workflow (select Unity version, add Android/iOS build support).
4) For iOS, add signing credentials (Apple cert & provisioning) in Codemagic or Unity Cloud Build.
5) Start the build — Codemagic will produce an .apk (Android) and .ipa (iOS/TestFlight) artifacts you can download.

See README_BUILD.md for detailed step-by-step links and tips.

If you want, I can now:
- generate a more complete Unity project including a basic scene, UI prefabs and playable logic (you'd still need to open in Unity to compile), OR
- walk you step-by-step while you configure Codemagic or Unity Cloud Build using this repo.

