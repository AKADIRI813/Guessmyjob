README_BUILD.md
================

How to get a playable APK / IPA from this skeleton by using Codemagic or Unity Cloud Build.

Option A — Codemagic (recommended if you don't have a Mac)
---------------------------------------------------------
1. Create a Git repository (GitHub/GitLab/Bitbucket) and push this project folder to it.
2. Sign up at Codemagic: https://codemagic.io/
3. Add a new app and connect your repository.
4. Configure workflow:
   - Select "Unity" as framework.
   - Choose the Unity Editor version (match your local Unity or a supported one).
   - Ensure Android and/or iOS build support modules are selected.
   - For Android: configure keystore (upload keystore or use Codemagic-managed).
   - For iOS: configure code signing (Apple Developer account, certificate & provisioning profile).
5. Start a build. When finished, download the APK (Android) or IPA/TestFlight link (iOS).
Useful docs: https://docs.codemagic.io/yaml-quick-start/building-a-unity-app/ and https://codemagic.io/start/

Option B — Unity Cloud Build / Unity Build Automation
----------------------------------------------------
1. Create a repository and push this project.
2. In Unity Dashboard, enable Cloud Build / Build Automation.
3. Connect your repo and configure build target for Android / iOS.
4. Configure code signing for iOS and keystore for Android.
5. Start build and download artifacts.
Docs: https://docs.unity3d.com/Manual/UnityCloudBuild.html and https://docs.unity.com/ugs/manual/devops/manual/build-automation/overview

Notes about iOS code signing:
- Building an IPA for distribution requires an Apple Developer account and correctly configured provisioning profiles and certificates.
- Cloud services can manage signing for you but you'll need to supply the credentials / profiles.
- If you want to submit to the App Store, you'll need an App Store Connect account and comply with Apple's rules.

Helpful tips:
- Keep the Unity version consistent between your project and the cloud builder.
- Test Android builds first — they are simpler (keystore only).
- Use TestFlight (via App Store Connect) to distribute iOS test builds.
- If you need, I can create a codemagic.yaml example workflow for this project.

