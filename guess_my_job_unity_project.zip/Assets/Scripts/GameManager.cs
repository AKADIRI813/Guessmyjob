using UnityEngine;
using System.Collections.Generic;
using System.IO;

// Simple GameManager skeleton for "Guess My Job"
// Attach this script to an empty GameObject in your Unity scene.
public class GameManager : MonoBehaviour
{
    public TextAsset stringsJson;
    public TextAsset jobsJson;

    private LocalizationData localization;
    private JobsData jobsData;

    void Awake()
    {
        LoadStrings();
        LoadJobs();
    }

    void LoadStrings()
    {
        if (stringsJson != null)
        {
            localization = JsonUtility.FromJson<LocalizationData>(stringsJson.text);
            Debug.Log("Loaded localization. Title (EN): " + localization.title.en);
        }
        else
        {
            Debug.LogWarning("strings.json not assigned in inspector");
        }
    }

    void LoadJobs()
    {
        if (jobsJson != null)
        {
            jobsData = JsonUtility.FromJson<JobsData>(jobsJson.text);
            Debug.Log("Loaded " + jobsData.jobs.Length + " jobs.");
        }
        else
        {
            Debug.LogWarning("jobs.json not assigned in inspector");
        }
    }

    // Placeholder: call to start a new match
    public void StartMatch()
    {
        // pick random job for player A
        var job = jobsData.jobs[Random.Range(0, jobsData.jobs.Length)];
        Debug.Log("Selected job (EN): " + job.en);
        // TODO: set up networking or local play
    }

    // Data containers for JSON parsing
    [System.Serializable]
    public class LocalizationData
    {
        public Title title;
        public Question[] questions;
    }

    [System.Serializable]
    public class Title { public string fr; public string en; public string ar; }

    [System.Serializable]
    public class Question { public string fr; public string en; public string ar; }

    [System.Serializable]
    public class JobsData { public Job[] jobs; }

    [System.Serializable]
    public class Job { public string fr; public string en; public string ar; }
}
